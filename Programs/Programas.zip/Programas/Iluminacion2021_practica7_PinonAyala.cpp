/*
Semestre 2021-2
Pr�ctica : Iluminaci�n
Cambios en el shader, en lugar de enviar la textura en el shader de fragmentos, enviaremos el finalcolor
*/
//para cargar imagen
#define STB_IMAGE_IMPLEMENTATION

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>
#include <math.h>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>
//para probar el importer
//#include<assimp/Importer.hpp>

#include "Window.h"
#include "Mesh.h"
#include "Shader_light.h"
#include "Camera.h"
#include "Texture.h"
#include "Sphere.h"
#include"Model.h"
#include "Skybox.h"


//para iluminaci�n
#include "CommonValues.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "Material.h"

const float toRadians = 3.14159265f / 180.0f;

Window mainWindow;
std::vector<Mesh*> meshList;
std::vector<Shader> shaderList;

Camera camera;

Texture brickTexture;
Texture dirtTexture;
Texture plainTexture;
Texture dadoTexture;
Texture pisoTexture;
Texture Tagave;


Model Kitt_M;
Model Peugeot;
Model Llanta_M;
Model Camino_M;
Model Blackhawk_M;
Model Dado_M;
Model Rines;
Model Flip;
Model R8;
Model Plano;
Model Hangar;
Model Puente;

Skybox skybox;

//materiales
Material Material_brillante;
Material Material_opaco;

//luz direccional
DirectionalLight mainLight;//sol
//para declarar varias luces de tipo pointlight
PointLight pointLights[MAX_POINT_LIGHTS];// ilumina alrededor como esfera
SpotLight spotLights[MAX_SPOT_LIGHTS];//ilumina en direccion como cono


//Sphere cabeza = Sphere(0.5, 20, 20);
GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;
GLfloat offset = 0.0f;

//*****************HELICOPTERO********************
GLboolean adelante = true;
GLfloat activo = 0.0f;
GLfloat topeRotacion = 90.0f;

GLfloat xa = 0.0f;
GLfloat ya = 0.0f;
GLfloat xb = 0.0f;
GLfloat yb = 0.0f;

GLfloat xBezier = 0.0f;
GLfloat zBezier = 0.0f;
GLfloat cuenta = 0.0f;

GLfloat posXavion = 0.0f;
GLfloat posYavion = 0.0f;

//****************CARRO***************************
GLboolean camino1 = true;
GLboolean adelanteCarro = true;
GLfloat arribaPuente = true;
GLfloat activoCarro = 0.0f;
GLfloat topeRotacionCarro = 180.0f;
GLfloat topeRotacionLuces = -1.0f;
GLfloat topeRotacionPuente = 0.0f;
GLboolean regresoPuente = true;

GLfloat xaCarro = 0.0f;
GLfloat yaCarro = 0.0f;
GLfloat xbCarro = 0.0f;
GLfloat ybCarro = 0.0f;

GLfloat xBezierCarro = 0.0f;
GLfloat zBezierCarro = 0.0f;
GLfloat cuentaCarro = 0.0f;

GLfloat posXcarro = 0.0f;
GLfloat posYcarro = 0.0f;
GLfloat terminoCarro=0.0;

class wcPt3D{
public:
    GLfloat x,y,z;
};


static double limitFPS = 1.0 / 60.0;


// Vertex Shader
static const char* vShader = "shaders/shader_light.vert";

// Fragment Shader
static const char* fShader = "shaders/shader_light.frag";

//funcion para la curva de bezier
GLfloat getPt( GLfloat n1 , GLfloat n2 , GLfloat perc )
{
    GLfloat diff = n2 - n1;
    return n1 + ( diff * perc );
}


//c�lculo del promedio de las normales para sombreado de Phong
void calcAverageNormals(unsigned int * indices, unsigned int indiceCount, GLfloat * vertices, unsigned int verticeCount,
    unsigned int vLength, unsigned int normalOffset)
{
    for (size_t i = 0; i < indiceCount; i += 3)
    {
        unsigned int in0 = indices[i] * vLength;
        unsigned int in1 = indices[i + 1] * vLength;
        unsigned int in2 = indices[i + 2] * vLength;
        glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1], vertices[in1 + 2] - vertices[in0 + 2]);
        glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1], vertices[in2 + 2] - vertices[in0 + 2]);
        glm::vec3 normal = glm::cross(v1, v2);
        normal = glm::normalize(normal);

        in0 += normalOffset; in1 += normalOffset; in2 += normalOffset;
        vertices[in0] += normal.x; vertices[in0 + 1] += normal.y; vertices[in0 + 2] += normal.z;
        vertices[in1] += normal.x; vertices[in1 + 1] += normal.y; vertices[in1 + 2] += normal.z;
        vertices[in2] += normal.x; vertices[in2 + 1] += normal.y; vertices[in2 + 2] += normal.z;
    }

    for (size_t i = 0; i < verticeCount / vLength; i++)
    {
        unsigned int nOffset = i * vLength + normalOffset;
        glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
        vec = glm::normalize(vec);
        vertices[nOffset] = vec.x; vertices[nOffset + 1] = vec.y; vertices[nOffset + 2] = vec.z;
    }
}




void CreateObjects()
{
    unsigned int indices[] = {
        0, 3, 1,
        1, 3, 2,
        2, 3, 0,
        0, 1, 2
    };

    GLfloat vertices[] = {
        //    x      y      z            u      v            nx      ny    nz
            -1.0f, -1.0f, -0.6f,    0.0f, 0.0f,        0.0f, 0.0f, 0.0f,
            0.0f, -1.0f, 1.0f,        0.5f, 0.0f,        0.0f, 0.0f, 0.0f,
            1.0f, -1.0f, -0.6f,        1.0f, 0.0f,        0.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f,        0.5f, 1.0f,        0.0f, 0.0f, 0.0f
    };

    unsigned int floorIndices[] = {
        0, 2, 1,
        1, 2, 3
    };

    GLfloat floorVertices[] = {
        -10.0f, 0.0f, -10.0f,    0.0f, 0.0f,        0.0f, -1.0f, 0.0f,
        10.0f, 0.0f, -10.0f,    10.0f, 0.0f,    0.0f, -1.0f, 0.0f,
        -10.0f, 0.0f, 10.0f,    0.0f, 10.0f,    0.0f, -1.0f, 0.0f,
        10.0f, 0.0f, 10.0f,        10.0f, 10.0f,    0.0f, -1.0f, 0.0f
    };

    unsigned int vegetacionIndices[] = {
        0, 1, 2,
        0, 2, 3,
        4,5,6,
        4,6,7
    };

    GLfloat vegetacionVertices[] = {
        -0.5f, -0.5f, 0.0f,        0.0f, 0.0f,        0.0f, 0.0f, 0.0f,
        0.5f, -0.5f, 0.0f,        1.0f, 0.0f,        0.0f, 0.0f, 0.0f,
        0.5f, 0.5f, 0.0f,        1.0f, 1.0f,        0.0f, 0.0f, 0.0f,
        -0.5f, 0.5f, 0.0f,        0.0f, 1.0f,        0.0f, 0.0f, 0.0f,

        0.0f, -0.5f, -0.5f,        0.0f, 0.0f,        0.0f, 0.0f, 0.0f,
        0.0f, -0.5f, 0.5f,        1.0f, 0.0f,        0.0f, 0.0f, 0.0f,
        0.0f, 0.5f, 0.5f,        1.0f, 1.0f,        0.0f, 0.0f, 0.0f,
        0.0f, 0.5f, -0.5f,        0.0f, 1.0f,        0.0f, 0.0f, 0.0f,
    };
    calcAverageNormals(indices, 12, vertices, 32, 8, 5);

    Mesh *obj1 = new Mesh();
    obj1->CreateMesh(vertices, indices, 32, 12);
    meshList.push_back(obj1);

    Mesh *obj2 = new Mesh();
    obj2->CreateMesh(vertices, indices, 32, 12);
    meshList.push_back(obj2);

    Mesh *obj3 = new Mesh();
    obj3->CreateMesh(floorVertices, floorIndices, 32, 6);
    meshList.push_back(obj3);

    calcAverageNormals(vegetacionIndices, 12, vegetacionVertices, 64, 8, 5);

    Mesh *obj4 = new Mesh();
    obj4->CreateMesh(vegetacionVertices, vegetacionIndices, 64, 12);
    meshList.push_back(obj4);

}

void CrearCubo()
{
    unsigned int cubo_indices[] = {
        // front
        0, 1, 2,
        2, 3, 0,
        // right
        4, 5, 6,
        6, 7, 4,
        // back
        8, 9, 10,
        10, 11, 8,

        // left
        12, 13, 14,
        14, 15, 12,
        // bottom
        16, 17, 18,
        18, 19, 16,
        // top
        20, 21, 22,
        22, 23, 20,
    };


    GLfloat cubo_vertices[] = {
        // front
        //x        y        z        S        T            NX        NY        NZ
        -0.5f, -0.5f,  0.5f,    0.27f,  0.35f,        0.0f,    0.0f,    -1.0f,    //0
        0.5f, -0.5f,  0.5f,        0.48f,    0.35f,        0.0f,    0.0f,    -1.0f,    //1
        0.5f,  0.5f,  0.5f,        0.48f,    0.64f,        0.0f,    0.0f,    -1.0f,    //2
        -0.5f,  0.5f,  0.5f,    0.27f,    0.64f,        0.0f,    0.0f,    -1.0f,    //3
        // right
        //x        y        z        S        T
        0.5f, -0.5f,  0.5f,        0.52f,  0.35f,        -1.0f,    0.0f,    0.0f,
        0.5f, -0.5f,  -0.5f,    0.73f,    0.35f,        -1.0f,    0.0f,    0.0f,
        0.5f,  0.5f,  -0.5f,    0.73f,    0.64f,        -1.0f,    0.0f,    0.0f,
        0.5f,  0.5f,  0.5f,        0.52f,    0.64f,        -1.0f,    0.0f,    0.0f,
        // back
        -0.5f, -0.5f, -0.5f,    0.77f,    0.35f,        0.0f,    0.0f,    1.0f,
        0.5f, -0.5f, -0.5f,        0.98f,    0.35f,        0.0f,    0.0f,    1.0f,
        0.5f,  0.5f, -0.5f,        0.98f,    0.64f,        0.0f,    0.0f,    1.0f,
        -0.5f,  0.5f, -0.5f,    0.77f,    0.64f,        0.0f,    0.0f,    1.0f,

        // left
        //x        y        z        S        T
        -0.5f, -0.5f,  -0.5f,    0.0f,    0.35f,        1.0f,    0.0f,    0.0f,
        -0.5f, -0.5f,  0.5f,    0.23f,  0.35f,        1.0f,    0.0f,    0.0f,
        -0.5f,  0.5f,  0.5f,    0.23f,    0.64f,        1.0f,    0.0f,    0.0f,
        -0.5f,  0.5f,  -0.5f,    0.0f,    0.64f,        1.0f,    0.0f,    0.0f,

        // bottom
        //x        y        z        S        T
        -0.5f, -0.5f,  0.5f,    0.27f,    0.02f,        0.0f,    1.0f,    0.0f,
        0.5f,  -0.5f,  0.5f,    0.48f,  0.02f,        0.0f,    1.0f,    0.0f,
         0.5f,  -0.5f,  -0.5f,    0.48f,    0.31f,        0.0f,    1.0f,    0.0f,
        -0.5f, -0.5f,  -0.5f,    0.27f,    0.31f,        0.0f,    1.0f,    0.0f,

        //UP
         //x        y        z        S        T
         -0.5f, 0.5f,  0.5f,    0.27f,    0.68f,        0.0f,    -1.0f,    0.0f,
         0.5f,  0.5f,  0.5f,    0.48f,  0.68f,        0.0f,    -1.0f,    0.0f,
          0.5f, 0.5f,  -0.5f,    0.48f,    0.98f,        0.0f,    -1.0f,    0.0f,
         -0.5f, 0.5f,  -0.5f,    0.27f,    0.98f,        0.0f,    -1.0f,    0.0f,

    };

    Mesh *cubo = new Mesh();
    cubo->CreateMesh(cubo_vertices, cubo_indices, 192, 36);
    meshList.push_back(cubo);

}



void CreateShaders()
{
    Shader *shader1 = new Shader();
    shader1->CreateFromFiles(vShader, fShader);
    shaderList.push_back(*shader1);
}



int main()
{
    mainWindow = Window(1366, 768); // 1280, 1024 or 1024, 768
    mainWindow.Initialise();

    CreateObjects();
    CrearCubo();
    meshList[0]->Bind();
    CreateShaders();

    camera = Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), -60.0f, 0.0f, 0.5f, 0.5f);

    brickTexture = Texture("Textures/brick.png");
    brickTexture.LoadTextureA();
    dirtTexture = Texture("Textures/dirt.png");
    dirtTexture.LoadTextureA();
    plainTexture = Texture("Textures/plain.png");
    plainTexture.LoadTextureA();
    dadoTexture = Texture("Textures/dado.tga");
    dadoTexture.LoadTextureA();
    pisoTexture = Texture("Textures/tierra.tga");
    pisoTexture.LoadTextureA();
    Tagave = Texture("Textures/Agave.tga");
    Tagave.LoadTextureA();

    Flip = Model();
    Flip.LoadModel("Models/flip.fbx");
    Peugeot = Model();
    Peugeot.LoadModel("Models/Ptuned.obj");
    Rines = Model();
    Rines.LoadModel("Models/Rines.obj");
    Kitt_M = Model();
    Kitt_M.LoadModel("Models/kitt.obj");
    Llanta_M = Model();
    Llanta_M.LoadModel("Models/k_rueda.3ds");
    Blackhawk_M = Model();
    Blackhawk_M.LoadModel("Models/uh60.obj");
    Camino_M = Model();
    Camino_M.LoadModel("Models/railroad track.obj");
    R8 = Model();
    R8.LoadModel("Models/AudiR8.obj");
    Plano = Model();
    Plano.LoadModel("Models/Plano.obj");
    Hangar = Model();
    Hangar.LoadModel("Models/Hangar.fbx");
    Puente = Model();
    Puente.LoadModel("Models/puente.fbx");

    Dado_M = Model();
    Dado_M.LoadModel("Models/dadoFauna.obj");

    std::vector<std::string> skyboxFaces;
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_rt.tga");
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_lf.tga");
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_dn.tga");
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_up.tga");
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_bk.tga");
    skyboxFaces.push_back("Textures/Skybox/cupertin-lake_ft.tga");

    skybox = Skybox(skyboxFaces);

    Material_brillante = Material(4.0f, 256);
    Material_opaco = Material(0.3f, 4);

    //posici�n inicial del helic�ptero
    glm::vec3 posblackhawk = glm::vec3(-40.0f, 6.0f, 30.0);
    glm::vec3 desplazamiento = posblackhawk;
    glm::vec3 carro= glm::vec3(20.0f, 4.4f, -1.5f);
    glm::vec3 desplazamientoCarro = carro;

    //luz direccional, s�lo 1 y siempre debe de existir
    mainLight = DirectionalLight(1.0f, 1.0f, 1.0f,//color de la luz
        0.3f, 0.3f,//1.- color 2.-
        0.0f, 0.0f, -1.0f);//hacia donde olumina
    //contador de luces puntuales
    unsigned int pointLightCount = 0;// arrelo de tipo puntual
    //Declaraci�n de primer luz puntual
    pointLights[0] = PointLight(1.0f, 0.0f, 0.0f, //rojo
        0.0f, 1.0f,
        2.0f, 1.5f, 1.5f,
        0.3f, 0.2f, 0.1f);//sirven para la atenuacion, alcance de la iluminacion
    pointLightCount++;

    unsigned int spotLightCount = 0;//arreglo spotlight
    //linterna
    spotLights[0] = SpotLight(1.0f, 1.0f, 1.0f,//color
        0.0f, 2.0f,//ambienta y difusa
        0.0f, 0.0f, 0.0f,//pos
        0.0f, -1.0f, 0.0f,//vector de direccion
        1.0f, 0.0f, 0.0f,//ecuacion
        5.0f);//apertura del cono
    spotLightCount++;

    //luz del faro 1
    spotLights[1] = SpotLight(1.0f, 1.0f, 1.0f,
        1.0f, 2.0f,
        0.0f, 0.0f, 0.0f,
        0.0f, -0.2f, 1.0f,
        1.0f, 0.0f, 0.0f,
        10.0f);
    spotLightCount++;
        
    //luz de faro 2
    spotLights[2] = SpotLight(1.0f, 1.0f, 1.0f,
        1.0f, 2.0f,
        0.0f, 0.0f, 0.0f,
        0.0f, -0.2f, 1.0f,
        1.0f, 0.0f, 0.0f,
        10.0f);
    spotLightCount++;
    
    //luz faro 1 2do auto
    spotLights[3] = SpotLight(1.0f, 1.0f, 1.0f,
        1.0f, 2.0f,
        0.0f, 0.0f, 0.0f,
        0.0f, -0.33f, 1.0f,
        1.0f, 0.0f, 0.0f,
        18.0f);
    spotLightCount++;
    
    //luz faro 2 2do auto
    spotLights[4] = SpotLight(1.0f, 1.0f, 1.0f,
        1.0f, 2.0f,
        0.0f, 0.0f, 0.0f,
        0.0f, -0.33f, 1.0f,
        1.0f, 0.0f, 0.0f,
        18.0f);
    spotLightCount++;
    
    //helicoptero
    spotLights[5] = SpotLight(1.0f, 1.0f, 1.0f,
        1.0f, 2.0f,
        0.0f, 0.0f, 0.0f,
        -0.5f, -1.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        15.0f);
    spotLightCount++;

    GLuint uniformProjection = 0, uniformModel = 0, uniformView = 0, uniformEyePosition = 0,
        uniformSpecularIntensity = 0, uniformShininess = 0;
    glm::mat4 projection = glm::perspective(45.0f, (GLfloat)mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 300.0f);
    
    
    ////Loop mientras no se cierra la ventana
    while (!mainWindow.getShouldClose())
    {
        
        GLfloat now = glfwGetTime();
        deltaTime = now - lastTime;
        deltaTime += (now - lastTime) / limitFPS;
        lastTime = now;

        //Recibir eventos del usuario
        glfwPollEvents();
        camera.keyControl(mainWindow.getsKeys(), deltaTime);
        camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

        // Clear the window
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        skybox.DrawSkybox(camera.calculateViewMatrix(), projection);
        shaderList[0].UseShader();
        uniformModel = shaderList[0].GetModelLocation();
        uniformProjection = shaderList[0].GetProjectionLocation();
        uniformView = shaderList[0].GetViewLocation();
        uniformEyePosition = shaderList[0].GetEyePositionLocation();

        //informaci�n en el shader de intensidad especular y brillo
        uniformSpecularIntensity = shaderList[0].GetSpecularIntensityLocation();
        uniformShininess = shaderList[0].GetShininessLocation();

        glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
        glUniform3f(uniformEyePosition, camera.getCameraPosition().x, camera.getCameraPosition().y, camera.getCameraPosition().z);

        //luz ligada a la c�mara de tipo flash
        glm::vec3 lowerLight = camera.getCameraPosition();
        lowerLight.y -= 0.3f;
        spotLights[0].SetFlash(lowerLight, camera.getCameraDirection());
        spotLights[3].SetPos(glm::vec3(-3.50f, 4.0f, 25.0f+mainWindow.getmuevex()));
        spotLights[4].SetPos(glm::vec3(5.0f, 4.0f, 25.0f+mainWindow.getmuevex()));
        
        //informaci�n al shader de fuentes de iluminaci�n
        shaderList[0].SetDirectionalLight(&mainLight);
        shaderList[0].SetPointLights(pointLights, pointLightCount);
        shaderList[0].SetSpotLights(spotLights, spotLightCount);


        glm::mat4 model(1.0);
        glm::mat4 modelaux(1.0);
        glm::mat4 modelPeugeot(1.0);



        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(30.0f, 1.0f, 30.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        pisoTexture.UseTexture();
        //agregar material al plano de piso
        Material_opaco.UseMaterial(uniformSpecularIntensity, uniformShininess);
        meshList[2]->RenderMesh();

        
        
        //agregar al coche
        //agregar su coche y ponerle material
        /*model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(30.0f, 1.50f, 11.0f+ mainWindow.getmuevex()));
        modelaux = model;
        model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Kitt_M.RenderModel();
        
        
        //llanta delantera 1
        model = modelaux;
        model = glm::translate(model, glm::vec3(-0.3f,-0.4f,-5.0f));
        model = glm::scale(model, glm::vec3(0.035f, 0.015f, 0.015f));
        model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Llanta_M.RenderModel();
        
        //llanta trasera 1
        model = modelaux;
        model = glm::translate(model, glm::vec3(-0.3f,-0.4f,-13.6f));
        model = glm::scale(model, glm::vec3(0.035f, 0.015f, 0.015f));
        model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Llanta_M.RenderModel();
        
        //delantera 2
        model = modelaux;
        model = glm::translate(model, glm::vec3(5.5f,-0.4f,-5.0f));
        model = glm::scale(model, glm::vec3(0.035f, 0.015f, 0.015f));
        model = glm::rotate(model, 270 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Llanta_M.RenderModel();
        
        model = modelaux;
        model = glm::translate(model, glm::vec3(5.5f,-0.4f,-13.6f));
        model = glm::scale(model, glm::vec3(0.035f, 0.015f, 0.015f));
        model = glm::rotate(model, 270 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Llanta_M.RenderModel();*/
        
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(20.0f, 0.0f, -1.5f));
        model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(25.0f, 1.0f, 1.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Camino_M.RenderModel();
        
        //agregar su coche y ponerle material
        
//*************************************DESPLAZAMIENTO Y TOTACION DEL COCHE***********************************
        
        if(desplazamientoCarro.z < -40.0f and cuentaCarro<1){
            //Funciones de bezier para trazar las curvas
            activoCarro=1.0f;
            adelanteCarro=false;
            cuentaCarro=cuentaCarro+0.01;
            xaCarro = getPt( 0.0f , -20.0f , cuentaCarro );
            yaCarro = getPt( 0.0f , -15.0f , cuentaCarro );
            xbCarro = getPt( -20.0f , 0.0f , cuentaCarro );
            ybCarro = getPt( -15.0f , -30.0f , cuentaCarro );

            // The Black Dot
            xBezierCarro = getPt( xaCarro , xbCarro , cuentaCarro );
            zBezierCarro = getPt( yaCarro , ybCarro , cuentaCarro );
        }
                
        if(cuentaCarro>0.99 and activoCarro == 1.0f){
            activoCarro =0.0f;
            adelanteCarro = false;
            cuentaCarro=0.0f;
            camino1 = false;
        }
        
        if(desplazamientoCarro.z > 10.0f and cuentaCarro<1){
            //Funciones de bezier para trazar las curvas
            activoCarro=2.0f;
            adelanteCarro=false;
            topeRotacionPuente=0.0f;
            regresoPuente=true;
            cuentaCarro=cuentaCarro+0.01;
            xaCarro = getPt( 0.0f , 20.0f , cuentaCarro );
            yaCarro = getPt( -30.0f , -15.0f , cuentaCarro );
            xbCarro = getPt( 20.0f , 0.0f , cuentaCarro );
            ybCarro = getPt( -15.0f , 0.0f , cuentaCarro );

            // The Black Dot
            xBezierCarro = getPt( xaCarro , xbCarro , cuentaCarro );
            zBezierCarro = getPt( yaCarro , ybCarro , cuentaCarro );
        }
        
        if(cuentaCarro>0.99 and activoCarro == 2.0f){
            activoCarro =0.0f;
            adelanteCarro= true;
            cuentaCarro=0.0f;
            camino1=true;
        }

       if(adelanteCarro and activoCarro==0.0f){
            posXcarro -= 0.1*deltaTime;
            posYcarro=0.0f;
           arribaPuente=true;
        }
        else if(activoCarro==0.0f){
            if(posYcarro<=10.0 and arribaPuente){
                posYcarro+=0.04;
            }else{
                arribaPuente=false;
                posYcarro-=0.04;
                if(posYcarro<=0){
                    posYcarro=0.0f;
                }
            }
            posXcarro += 0.1*deltaTime;
        }
        
        desplazamientoCarro = glm::vec3(carro.x + zBezierCarro, carro.y+posYcarro,carro.z + xBezierCarro + posXcarro + mainWindow.getmuevex() );
        
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(desplazamientoCarro));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        
        if(adelanteCarro and activoCarro==0.0f){
            
            topeRotacionCarro=180.0f;
            model = glm::rotate(model, topeRotacionCarro * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
            
        }else if (activoCarro == 0.0f){
            
            if(topeRotacionPuente>=-25.0f and arribaPuente){
                if(topeRotacionPuente>=-16.0f and regresoPuente){
                    topeRotacionPuente=topeRotacionPuente-0.1f;
                }else{
                    regresoPuente=false;
                    if(topeRotacionPuente>=0.0f){
                        topeRotacionPuente=0.0f;
                    }else{
                        topeRotacionPuente=topeRotacionPuente+0.1f;
                    }
                }
            }
            if(arribaPuente==false){
                topeRotacionPuente=topeRotacionPuente+0.1f;
            }
            
            topeRotacionCarro=0.0f;
            model = glm::rotate(model, topeRotacionPuente * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
            model = glm::rotate(model, topeRotacionCarro * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        }
                
        if ( activoCarro == 1.0f){
            topeRotacionCarro=topeRotacionCarro+2.0f;
            model = glm::rotate(model, topeRotacionCarro * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
            if(topeRotacionCarro >= 360.0f){
                topeRotacionCarro=360.0f;
            }
        }
        if ( activoCarro == 2.0f){
            topeRotacionCarro=topeRotacionCarro+2.0f;
            model = glm::rotate(model, topeRotacionCarro * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
            if(topeRotacionCarro >= 180.0f){
                topeRotacionCarro=180.0f;
            }
        }
        //*************LUCES**************************
           
        if(camino1==true){ spotLights[1].SetFlash(glm::vec3(desplazamientoCarro.x+2.6f,desplazamientoCarro.y-1.2,desplazamientoCarro.z-5.8f),glm::vec3(0.0f, -0.2f, -1.0f));
        spotLights[2].SetFlash(glm::vec3(desplazamientoCarro.x-2.6f,desplazamientoCarro.y-1.2,desplazamientoCarro.z-5.8f),glm::vec3(0.0f, -0.2f, -1.0f));
        }else if(camino1==false and activoCarro==0.0f){
        spotLights[1].SetFlash(glm::vec3(desplazamientoCarro.x+2.6f,desplazamientoCarro.y-1.2,desplazamientoCarro.z+5.8f),glm::vec3(0.0f, -0.2f, 1.0f));
        spotLights[2].SetFlash(glm::vec3(desplazamientoCarro.x-2.6f,desplazamientoCarro.y-1.2,desplazamientoCarro.z+5.8f),glm::vec3(0.0f, -0.2f, 1.0f));
        }
        
//*************************************DESPLAZAMIENTO Y TOTACION DEL COCHE***********************************
        
        modelPeugeot = model;
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Peugeot.RenderModel();
        
        
        model = modelPeugeot;
        model = glm::translate(model, glm::vec3(-3.1f, -3.0f, -5.7f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, 0+mainWindow.getmuevex() * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Rines.RenderModel();
        
        model = modelPeugeot;
        model = glm::translate(model, glm::vec3(3.1f, -3.0f, -5.7f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        model = glm::rotate(model, 0+mainWindow.getmuevex() * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Rines.RenderModel();
    
        //rin delantero 1
        model = modelPeugeot;
        model = glm::translate(model, glm::vec3(-3.1f, -3.0f, 5.9f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        
        if(mainWindow.getLucesDelante()){
            model = glm::rotate(model, 0+mainWindow.getmuevex() * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        }else{
            model = glm::rotate(model, 0-mainWindow.getmuevex() * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        }

        model = glm::rotate(model, 0+mainWindow.getGira() * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Rines.RenderModel();
        
        //rin delantero 2
        model = modelPeugeot;
        model = glm::translate(model, glm::vec3(3.1f, -3.0f, 5.9f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        model = glm::rotate(model, 0+mainWindow.getmuevex() * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, 0+mainWindow.getGira() * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Rines.RenderModel();
        
        //agregar incremento en X con teclado
        model = glm::mat4(1.0);
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
        
        offset += 0.1;
        posYavion = sin(5*offset * toRadians); //arriba y abajo
        
        desplazamiento = glm::vec3(posblackhawk.x+posXavion+mainWindow.getmuevex()+xBezier, posblackhawk.y+posYavion+mainWindow.getDespega(),posblackhawk.z+zBezier);
        
//*************************************DESPLAZAMIENTO Y TOTACION DEL HELICOPTERO***********************************
        if(desplazamiento.x < -80.0f and cuenta<1){
            //Funciones de bezier para trazar las curvas
            activo=1.0f;
            adelante=false;
            cuenta=cuenta+0.01;
            xa = getPt( 0.0f , -20.0f , cuenta );
            ya = getPt( 0.0f , -15.0f , cuenta );
            xb = getPt( -20.0f , 0.0f , cuenta );
            yb = getPt( -15.0f , -30.0f , cuenta );

            // The Black Dot
            xBezier = getPt( xa , xb , cuenta );
            zBezier = getPt( ya , yb , cuenta );
        }
        
        if(cuenta>0.99 and activo == 1.0f){
            activo =0.0f;
            adelante = false;
            cuenta=0.0f;
        }
        
        if(desplazamiento.x > -30.0f and cuenta<1){
            //Funciones de bezier para trazar las curvas
            activo=2.0f;
            adelante=false;
            cuenta=cuenta+0.01;
            xa = getPt( 0.0f , 20.0f , cuenta );
            ya = getPt( -30.0f , -15.0f , cuenta );
            xb = getPt( 20.0f , 0.0f , cuenta );
            yb = getPt( -15.0f , 0.0f , cuenta );

            // The Black Dot
            xBezier = getPt( xa , xb , cuenta );
            zBezier = getPt( ya , yb , cuenta );
        }
        
        if(cuenta>0.99 and activo == 2.0f){
            activo =0.0f;
            adelante = true;
            cuenta=0.0f;
        }

        if(adelante and activo==0.0f){
            posXavion -= 0.1*deltaTime;
        }
        else if(activo==0.0f){
            posXavion += 0.1*deltaTime;
        }

        
        model = glm::translate(model, glm::vec3(desplazamiento));
        spotLights[5].SetPos(desplazamiento);
        model = glm::rotate(model, -90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        
        if(adelante and activo==0.0f){
            topeRotacion=90.0f;
            model = glm::rotate(model, topeRotacion * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
        }else if (activo == 0.0f){
            topeRotacion=-90.0f;
            model = glm::rotate(model, topeRotacion * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
        }
        
        if ( activo == 1.0f){
            topeRotacion=topeRotacion-1.8;
            model = glm::rotate(model, topeRotacion * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
            if(topeRotacion <= -90.0f){
                topeRotacion=-90.0f;
            }
        }
        if ( activo == 2.0f){
                topeRotacion=topeRotacion-1.8;
                model = glm::rotate(model, topeRotacion * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
                if(topeRotacion >= 90.0f){
                    topeRotacion=90.0f;
                }
        }
//*************************************DESPLAZAMIENTO Y TOTACION DEL HELICOPTERO***********************************
        
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //agregar material al helic�ptero
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Blackhawk_M.RenderModel();
        //�C�mo ligas la luz al helic�ptero?
        
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //agregar material al helic�ptero
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Flip.RenderModel();
        
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 20.0f));
        model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //agregar material al helic�ptero
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        R8.RenderModel();
        
        model = glm::mat4(1.0);
        model = glm::scale(model, glm::vec3(0.5f, 4.8f, 0.4f));
        model = glm::translate(model, glm::vec3(-20.0f, 4.2f, -35.0f));
        model = glm::rotate(model, -90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //agregar material al helic�ptero
        Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
        Puente.RenderModel();
        
        /*model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, -1.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //agregar material al helic�ptero
        Plano.RenderModel();*/
        
        
        /*model = glm::mat4(1.0);
        model = glm::scale(model, glm::vec3(20.0f, 20.0f, 3.0f));
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, -20.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        Hangar.RenderModel();*/
        
        //Agave que sucede si lo renderizan antes del coche y la pista
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f,0.0f,10.0f));
        model = glm::scale(model, glm::vec3(5.0f,5.0f,5.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //blending transparencia o traslucidez = SOLO SE TRANSPARENTA EL SKYBOX
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        Tagave.UseTexture();
        Material_opaco.UseMaterial(uniformSpecularIntensity, uniformShininess);
        meshList[3]->RenderMesh();
        glDisable(GL_BLEND);
        
        //ANIMACION BASICA NO ES UNA TRASLACION NI ROTACION NI ESCALA
        //DEBE SER LA COMBINACION DE AMBAS
        
        //COMPLEJA = UNIMACION BASADA EN FUNCIONES, ECUACIONES QUE EXISTEN COMO
        //CAIDA LIBRE TIRO PRABOLICO, FUNCIONES DE CURVA, MOVIMIENTOS FISICOS
        
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f,0.0f,-10.0f));
        model = glm::scale(model, glm::vec3(5.0f,5.0f,5.0f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        //blending transparencia o traslucidez
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        Tagave.UseTexture();
        Material_opaco.UseMaterial(uniformSpecularIntensity, uniformShininess);
        meshList[3]->RenderMesh();
        glDisable(GL_BLEND);

        glUseProgram(0);

        mainWindow.swapBuffers();
    }

    return 0;
}

